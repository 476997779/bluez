/*
 *
 *  BlueZ - Bluetooth protocol stack for Linux
 *
 *  Copyright (C) 2004-2009  Marcel Holtmann <marcel@holtmann.org>
 *  Copyright (C) 2009 The Android Open Source Project
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#include <unistd.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/prctl.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>

static int hci_vendor_open_dev() {
    int sock = socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI);
    struct sockaddr_hci addr;
    int opt;

    if(sock < 0) {
        error("Can't create raw HCI socket!");
        return -1;
    }

    opt = 1;
    if (setsockopt(sock, SOL_HCI, HCI_DATA_DIR, &opt, sizeof(opt)) < 0) {
        error("Error setting data direction\n");
        return -1;
    }

    /* Bind socket to the HCI device */
    memset(&addr, 0, sizeof(addr));
    addr.hci_family = AF_BLUETOOTH;
    addr.hci_dev = 0;  // hci0
    if(bind(sock, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
        error("Can't attach to device hci0. %s(%d)\n",
			  strerror(errno),
			  errno);
        return -1;
    }
    return sock;
}


static int hci_vendor_get_acl_handle(int fd, bdaddr_t *bdaddr) {
int i;
int ret = -1;
struct hci_conn_list_req *conn_list;
struct hci_conn_info *conn_info;
int max_conn = 10;

conn_list = malloc(max_conn * (
					   sizeof(struct hci_conn_list_req) + sizeof(struct hci_conn_info)));
if (!conn_list) {
	error("Out of memory in %s\n", __FUNCTION__);
	return -1;
}

conn_list->dev_id = 0;  /* hardcoded to HCI device 0 */
conn_list->conn_num = max_conn;

if (ioctl(fd, HCIGETCONNLIST, (void *)conn_list)) {
	error("Failed to get connection list\n");
	goto out;
}

for (i=0; i < conn_list->conn_num; i++) {
	conn_info = &conn_list->conn_info[i];
	if (conn_info->type == ACL_LINK &&
			!memcmp((void *)&conn_info->bdaddr, (void *)bdaddr,
					sizeof(bdaddr_t))) {
		ret = conn_info->handle;
		goto out;
	}
}
ret = 0;

out:
free(conn_list);
return ret;
}

static int hci_vendor_setup_qos(int fd, uint16_t handle, int pri) {
	int ret = 0;
	unsigned char hci_qos_cmd[] = {
        0x01,               // HCI command packet
        0x07, 0x08,         // HCI_CP_SETUP_QOS
        0x14,               // Length
        0x00, 0x00,          // Handle
        0X00,		//FLAGS
        0X02,		//SERVICE_TYPE
        0X40,0X0d,0X03,0X00,	//token_rate
        0X40,0X0d,0X03,0X00,	//peak_bandwidth
        0x01,0x00,0X00,0X00,	//latency
        0xFF,0xFF,0XFF,0XFF		//delay_variation
    };
	unsigned char hci_qos_cmd2[] = {
        0x01,               // HCI command packet
        0x07, 0x08,         // HCI_CP_SETUP_QOS
        0x14,               // Length
        0x00, 0x00,          // Handle
        0X00,		//FLAGS
        0X01,		//SERVICE_TYPE
        0X00,0X00,0X00,0X00,	//token_rate
        0x00,0x00,0X00,0X00,	//peak_bandwidth
        0x01,0x00,0X00,0X00,	//latency
        0xFF,0xFF,0XFF,0XFF		//delay_variation
    };

    hci_qos_cmd[4] = (uint8_t)handle;
    hci_qos_cmd[5] = (uint8_t)(handle >> 8);
    hci_qos_cmd2[4] = (uint8_t)handle;
    hci_qos_cmd2[5] = (uint8_t)(handle >> 8);

    error("brcm set high priority %d", pri);
    if(pri == 1){
		ret = write(fd, hci_qos_cmd2, sizeof(hci_qos_cmd2));
    }else{
		ret = write(fd, hci_qos_cmd, sizeof(hci_qos_cmd));
    }
    if (ret < 0) {
        error("write(): %s (%d)]", strerror(errno), errno);
        return -1;
    } else if (ret != sizeof(hci_qos_cmd)) {
        error("write(): unexpected length %d", ret);
        return -1;
    }
    return 0;
}

/* Request that the ACL link to a given Bluetooth connection be high priority,
 * for improved coexistance support
 */
int hci_vendor_set_high_qos(bdaddr_t *ba) {
    int ret;
    int fd = hci_vendor_open_dev( );
    int acl_handle;

    if (fd < 0)
        return fd;

    acl_handle = hci_vendor_get_acl_handle(fd, ba);
    if (acl_handle < 0) {
        ret = acl_handle;
        goto out;
    }

    ret = hci_vendor_setup_qos(fd, acl_handle, 0x2);
    if (ret < 0)
        goto out;

out:
    close(fd);

    return ret;
}

int hci_vendor_set_normal_qos(bdaddr_t *ba) {
    int ret;
    int fd = hci_vendor_open_dev( );
    int acl_handle;

    if (fd < 0)
        return fd;

    acl_handle = hci_vendor_get_acl_handle(fd, ba);
    if (acl_handle < 0) {
        ret = acl_handle;
        goto out;
    }

    ret = hci_vendor_setup_qos(fd, acl_handle, 0x1);
    if (ret < 0)
        goto out;

out:
    close(fd);
    return ret;
}



