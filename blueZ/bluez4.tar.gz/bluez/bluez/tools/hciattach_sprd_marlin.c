/*
 *
 *  BlueZ - Bluetooth protocol stack for Linux
 *
 *  Copyright (C) 2005-2010  Marcel Holtmann <marcel@holtmann.org>
 *  Copyright (c) 2010, Code Aurora Forum. All rights reserved.
 *
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <time.h>


#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>
#include "hciattach_sprd_marlin.h"



extern int bt_getPskeyFromFile(void *pData);

// pskey file structure default value
static BT_PSKEY_CONFIG_T bt_para_setting={
    .pskey_cmd = 0x001C0101,

    .g_dbg_source_sink_syn_test_data = 0,
    .g_sys_sleep_in_standby_supported = 0,
    .g_sys_sleep_master_supported = 0,
    .g_sys_sleep_slave_supported = 0,

    .default_ahb_clk = 26000000,
    .device_class = 0x001F00,
    .win_ext = 30,

    .g_aGainValue = {0x0000F600, 0x0000D000, 0x0000AA00, 0x00008400, 0x00004400, 0x00000A00},
    .g_aPowerValue = {0x0FC80000, 0x0FF80000, 0x0FDA0000, 0x0FCC0000, 0x0FFC0000},

    .feature_set = {0xFF, 0xFF, 0x8D, 0xFE, 0x9B, 0x7F, 0x79, 0x83, 0xFF, 0xA7, 0xFF, 0x7F, 0x00, 0xE0, 0xF7, 0x3E},
    .device_addr = {0x6A, 0x6B, 0x8C, 0x8A, 0x8B, 0x8C},

    .g_sys_sco_transmit_mode = 0, //true tramsmit by uart, otherwise by share memory
    .g_sys_uart0_communication_supported = 1, //true use uart0, otherwise use uart1 for debug
    .edr_tx_edr_delay = 5,
    .edr_rx_edr_delay = 14,

    .g_wbs_nv_117 = 0x0031,

    .is_wdg_supported = 0,

    .share_memo_rx_base_addr = 0,
    //.share_memo_tx_base_addr = 0,
    .g_wbs_nv_118 = 0x0066,
    .g_nbv_nv_117 = 0x1063,

    .share_memo_tx_packet_num_addr = 0,
    .share_memo_tx_data_base_addr = 0,

    .g_PrintLevel = 0xFFFFFFFF,

    .share_memo_tx_block_length = 0,
    .share_memo_rx_block_length = 0,
    .share_memo_tx_water_mark = 0,
    //.share_memo_tx_timeout_value = 0,
    .g_nbv_nv_118 = 0x0E45,

    .uart_rx_watermark = 48,
    .uart_flow_control_thld = 63,
    .comp_id = 0,
    .pcm_clk_divd = 0x26,


    .reserved = {0}
};


/*
 * Read an HCI event from the given file descriptor.
 */
static int read_hci_event(int fd, unsigned char* buf, int size)
{
        int remain, r;
        int count = 0;

        if (size <= 0)
                return -1;

        /* The first byte identifies the packet type. For HCI event packets, it
         * should be 0x04, so we read until we get to the 0x04. */
        while (1) {
                r = read(fd, buf, 1);
                if (r <= 0)
                        return -1;
                if (buf[0] == 0x04)
                        break;
        }
        count++;

        /* The next two bytes are the event code and parameter total length. */
        while (count < 3) {
                r = read(fd, buf + count, 3 - count);
                if (r <= 0)
                        return -1;
                count += r;
        }

        /* Now we read the parameters. */
        if (buf[2] < (size - 3))
                remain = buf[2];
        else
                remain = size - 3;

        while ((count - 3) < remain) {
                r = read(fd, buf + count, remain - (count - 3));
                if (r <= 0)
                        return -1;
                count += r;
        }

        return count;
}

static void sprd_get_pskey(BT_PSKEY_CONFIG_T * pskey_t) {
    BT_PSKEY_CONFIG_T pskey;

    printf("%s\n", __func__);
    memset(&pskey, 0 , sizeof(BT_PSKEY_CONFIG_T));
    if (bt_getPskeyFromFile(&pskey) < 0 ) {
        fprintf(stderr, "bt_getPskeyFromFile failed\n");
        memcpy(pskey_t, &bt_para_setting, sizeof(BT_PSKEY_CONFIG_T));
        return;
    }

    /* get bluetooth mac address, need to implement*/
    //get_mac_address(pskey.device_addr);
    memcpy(pskey_t, &pskey, sizeof(BT_PSKEY_CONFIG_T));
}

static int readBDAddr(const char *filename, unsigned char *addr) {

	FILE* pFile = NULL;
	int result,i;
	char * pStr;

	int word[HEX_LENGTH_BD_ADDR];

	char text[STRING_LENGTH_BD_ADDR];

	memset(text,0,STRING_LENGTH_BD_ADDR);

	pFile = fopen(filename, "r");

	if(pFile)
	{
		pStr = fgets(text, MAX_LINE_LENGTH, pFile);
		if( !pStr)  {
			fprintf(stderr, "BT ADDR: file read fail!\n");
			return -1;
		}

		result = sscanf(text, "%02X%02X%02X%02X%02X%02X", &word[5],&word[4],&word[3],&word[2],&word[1],&word[0]);

		if (result != HEX_LENGTH_BD_ADDR) {
			fprintf(stderr, "BT ADDR: file read fail!\n");
			return -1;
		}

		for (i=0;i<HEX_LENGTH_BD_ADDR;i++)  {
			addr[i]=word[i];
		}

		return 0;
	}
	else
	{
		fprintf(stderr, "BT ADDR: file open fail!\n");
		return -1;
	}

}

static void writeBDAddr(const char *filename, const unsigned char *addr) {
	int fd;

	char addrstr[STRING_LENGTH_BD_ADDR];

	fd=open(BT_ADDR_DEBUG_FILE_NAME, O_WRONLY | O_CREAT | O_TRUNC | O_SYNC, 0644);

    if(fd<0){
	    perror("can't open BD ADDR FILE\n");
    } else {
	    memset(addrstr,0,sizeof(addrstr));
	    sprintf(addrstr,"%02X%02X%02X%02X%02X%02X\n",
	            addr[5],addr[4],addr[3],addr[2],addr[1],addr[0]);
	    if(write(fd,addrstr,sizeof(addrstr))<0) {
		    perror("can't write BD ADDR FILE\n");
		}
	    close(fd);
    }

}

static void randomBDAddr(unsigned char *addr){
	int rand;
	int i;
	unsigned int seed;

	seed = time(NULL);
	for(i=0;i<4;i++){
		rand = rand_r(&seed)%256;
		addr[i]=rand;
	}

	addr[4]=BD_PREFIX&0xff;
	addr[5]=(BD_PREFIX>>8)&0xff;

}

static void getBDaddr(unsigned char *addr)
{
	if(readBDAddr(BT_ADDR_DEBUG_FILE_NAME, addr)!=0)
	{
		randomBDAddr(addr);
		writeBDAddr(BT_ADDR_DEBUG_FILE_NAME, addr);
	}

}

static int sprd_load_firmware(int fd)
{
	int i;
    unsigned char cmd[HCI_CMD_PREAMBLE_SIZE+PSKEY_PREAMBLE_SIZE];
	unsigned char resp[CC_MIN_SIZE];

	BT_PSKEY_CONFIG_T pskey;
	BT_PSKEY_CONFIG_T * bt_par = &pskey;

	printf("%s\n", __func__);
	sprd_get_pskey(&pskey);

	unsigned char * p= cmd;

    *p = HCI_COMMAND_PKT;
	p++;

	UINT16_TO_STREAM(p, HCI_WRITE_PSKEY);
    *p = PSKEY_PREAMBLE_SIZE;
    p++;

	UINT8_TO_STREAM(p, bt_par->g_dbg_source_sink_syn_test_data);
	UINT8_TO_STREAM(p, bt_par->g_sys_sleep_in_standby_supported);
	UINT8_TO_STREAM(p, bt_par->g_sys_sleep_master_supported);
	UINT8_TO_STREAM(p, bt_par->g_sys_sleep_slave_supported);

	UINT32_TO_STREAM(p, bt_par->default_ahb_clk);
	UINT32_TO_STREAM(p, bt_par->device_class);
	UINT32_TO_STREAM(p, bt_par->win_ext);

	for (i = 0; i < 6; i++) {
		UINT32_TO_STREAM(p, bt_par->g_aGainValue[i]);
	}
	for (i = 0; i < 5; i++) {
		UINT32_TO_STREAM(p, bt_par->g_aPowerValue[i]);
	}

	for (i = 0; i < 16; i++) {
		UINT8_TO_STREAM(p, bt_par->feature_set[i]);
	}

	getBDaddr(bt_par->device_addr);

	for (i = 0; i < 6; i++) {
		UINT8_TO_STREAM(p, bt_par->device_addr[i]);
	}

	UINT8_TO_STREAM(p, bt_par->g_sys_sco_transmit_mode);
	UINT8_TO_STREAM(p, bt_par->g_sys_uart0_communication_supported);
	UINT8_TO_STREAM(p, bt_par->edr_tx_edr_delay);
	UINT8_TO_STREAM(p, bt_par->edr_rx_edr_delay);

	UINT16_TO_STREAM(p, bt_par->g_wbs_nv_117);

	UINT32_TO_STREAM(p, bt_par->is_wdg_supported);

	UINT32_TO_STREAM(p, bt_par->share_memo_rx_base_addr);
	//UINT32_TO_STREAM(p, bt_par->share_memo_tx_base_addr);
	UINT16_TO_STREAM(p, bt_par->g_wbs_nv_118);
	UINT16_TO_STREAM(p, bt_par->g_nbv_nv_117);

	UINT32_TO_STREAM(p, bt_par->share_memo_tx_packet_num_addr);
	UINT32_TO_STREAM(p, bt_par->share_memo_tx_data_base_addr);

	UINT32_TO_STREAM(p, bt_par->g_PrintLevel);

	UINT16_TO_STREAM(p, bt_par->share_memo_tx_block_length);
	UINT16_TO_STREAM(p, bt_par->share_memo_rx_block_length);
	UINT16_TO_STREAM(p, bt_par->share_memo_tx_water_mark);
	//UINT16_TO_STREAM(p, bt_par->share_memo_tx_timeout_value);
	UINT16_TO_STREAM(p, bt_par->g_nbv_nv_118);

	UINT16_TO_STREAM(p, bt_par->uart_rx_watermark);
	UINT16_TO_STREAM(p, bt_par->uart_flow_control_thld);
	UINT32_TO_STREAM(p, bt_par->comp_id);
	UINT16_TO_STREAM(p, bt_par->pcm_clk_divd);


	for (i = 0; i < 8; i++) {
		UINT32_TO_STREAM(p, bt_par->reserved[i]);
	}


	if (write(fd, cmd, sizeof(cmd)) != sizeof(cmd)) {
		fprintf(stderr,"Failed to write download mode command\n");
		return -1;
	}

	if (read_hci_event(fd, resp, sizeof(resp)) < CC_MIN_SIZE) {
		fprintf(stderr,"Failed to load firmware, invalid HCI event\n");
		return -1;
	}

	if (resp[1] != PSKEY_EVENT || resp[3] != CMD_SUCCESS) {
		fprintf(stderr, "Failed to load firmware, command failure\n");
		return -1;
	}

	return 0;
}

/*
* configure bluetooth controller's serial port
*/
static void bt_config_uart(char config){

	int uart_fd = open(UART_INFO_PATH, O_WRONLY);

	if (uart_fd<0) {
	    perror("open uart info failed");
		return;
	}

	if (write(uart_fd, &config, 1) !=1 ){
	    fprintf(stderr, "write uart info failed\n");
    }

	close(uart_fd);
}

/*
* disable bluetooth sleep
*/
static void bt_wake_up(void){

    int   btsleep_fd = open(VENDOR_BTWRITE_PROC_NODE, O_WRONLY);

	if (btsleep_fd < 0) {
        perror("open btsleep failed");
		return;
	}

	char buffer = '1';
    if (write(btsleep_fd, &buffer, 1) != 1) {
        fprintf(stderr,"write btsleep failed\n");
    }
}

/*
* configure serial port
*/
static int sprd_config_uart(unsigned int fd)
{
    struct termios  term;

    if (tcflush(fd, TCIOFLUSH) < 0) {
        fprintf(stderr, "init_uart: Cannot flush tty\n");
        return -1;
    }

    if (tcgetattr(fd, &term) < 0) {
        perror("init_uart: Error while getting attributes");
        return -1;
    }

    cfmakeraw(&term);

    term.c_cflag |= CREAD;
	term.c_iflag &= ~(IXOFF);


    if (tcsetattr(fd, TCSANOW, &term) < 0){
        perror("init_uart: Error while setting attributes");
        return -1;
    }

    return 0;
}


int sprd_marlin_config_init(int fd, char *bdaddr, struct termios *ti)
{
    bt_wake_up();

	if( sprd_config_uart(fd) < 0) {
	    return -1;
	}

	bt_config_uart('2');

	if(sprd_load_firmware(fd) < 0) {
		bt_config_uart('3');
	    return -1;
	}

	bt_config_uart('3');

	/* should wait for a while before attach tty*/
	sleep(1);

	return 0;
}
